<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["social_login"] = "Social Login";
$lang["social_login_enable_google_login"] = "Google-Login aktivieren";
$lang["social_login_login_password_help_message"] = "Bitte stellen Sie es in Ihren Kontoeinstellungen ein";
$lang["social_login_duplicate_company_name"] = "Doppelter Firmenname";
$lang["social_login_continue_with_google"] = "Weiter mit Google";
$lang["social_login_enable_facebook_login"] = "Facebook-Login aktivieren";
$lang["social_login_continue_with_facebook"] = "Weiter mit Facebook";
$lang["social_login_remember_to_add_this_url_in_valid_oauth_redirect_uris"] = "Denken Sie daran, diese URL in gültige OAuth-Umleitungs-URIs hinzuzufügen";
$lang["social_login_facebook_https_error_help_message"] = "Die Facebook-Anmeldung funktioniert nur auf dem HTTPS-Server.";

return $lang;
