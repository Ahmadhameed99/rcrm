<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["social_login"] = "Accesso social";
$lang["social_login_enable_google_login"] = "Abilita Google Login";
$lang["social_login_login_password_help_message"] = "Impostalo dalle impostazioni del tuo account";
$lang["social_login_duplicate_company_name"] = "Nome azienda duplicato";
$lang["social_login_continue_with_google"] = "Continua con Google";
$lang["social_login_enable_facebook_login"] = "Abilita l'accesso a Facebook";
$lang["social_login_continue_with_facebook"] = "Continua con Facebook";
$lang["social_login_remember_to_add_this_url_in_valid_oauth_redirect_uris"] = "Ricorda di aggiungere questo URL negli URI di reindirizzamento OAuth validi";
$lang["social_login_facebook_https_error_help_message"] = "L'accesso a Facebook funzionerà solo su server HTTPS.";

return $lang;
