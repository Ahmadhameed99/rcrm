<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["social_login"] = "Κοινωνική σύνδεση";
$lang["social_login_enable_google_login"] = "Ενεργοποίηση σύνδεσης Google";
$lang["social_login_login_password_help_message"] = "Ορίστε το από τη ρύθμιση του λογαριασμού σας";
$lang["social_login_duplicate_company_name"] = "Διπλότυπο όνομα εταιρείας";
$lang["social_login_continue_with_google"] = "Συνέχεια με το Google";
$lang["social_login_enable_facebook_login"] = "Ενεργοποίηση σύνδεσης στο Facebook";
$lang["social_login_continue_with_facebook"] = "Συνέχεια με το Facebook";
$lang["social_login_remember_to_add_this_url_in_valid_oauth_redirect_uris"] = "Θυμηθείτε να προσθέσετε αυτό το url σε έγκυρα URI ανακατεύθυνσης OAuth";
$lang["social_login_facebook_https_error_help_message"] = "Η σύνδεση στο Facebook θα λειτουργεί μόνο στον διακομιστή HTTPS.";

return $lang;
