<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["social_login"] = "Вход в социальную сеть";
$lang["social_login_enable_google_login"] = "Включить вход в Google";
$lang["social_login_login_password_help_message"] = "Установите его в настройках своей учетной записи";
$lang["social_login_duplicate_company_name"] = "Повторяющееся название компании";
$lang["social_login_continue_with_google"] = "Продолжить с Google";
$lang["social_login_enable_facebook_login"] = "Включить вход в Facebook";
$lang["social_login_continue_with_facebook"] = "Продолжить с Facebook";
$lang["social_login_remember_to_add_this_url_in_valid_oauth_redirect_uris"] = "Не забудьте добавить этот URL в Действительные URI перенаправления OAuth";
$lang["social_login_facebook_https_error_help_message"] = "Вход в Facebook будет работать только на сервере HTTPS.";

return $lang;
