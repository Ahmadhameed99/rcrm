<div class="card mb0 p20">
    <div class="table-responsive general-form">
        <table id="custom-field-table-project_files" class="display no-thead b-t b-b-only no-hover" cellspacing="0" width="100%">            
        </table>
    </div>
</div>
<script type="text/javascript">
    $(document).ready(function () {
        loadCustomFieldTable("project_files");
    });
</script>